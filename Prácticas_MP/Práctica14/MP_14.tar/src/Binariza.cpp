/***************************************************************************/
//
// Autor: Juan Manuel Segura Duarte
//
// Programa que binariza una imagen pgm.
// Binariza <nombre_pgm_original> <valor_umbral> <nombre_pgm_binarizado>
//
// Fichero: Binariza.cpp
//
/***************************************************************************/

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdlib>

#include "Utils.h"

using namespace std;

int main (int argc, char * argv[]) {
	
	// Comprobar numero de argumentos

	if (argc != 4) {
		cerr << endl; 		
		cerr << "Error: Numero de argumentos incorrecto." << endl;
		cerr << "Uso: " << argv[0] << " <nombre_pgm_original> <valor_umbral> "
			 << "<nombre_pgm_binarizado>" << endl;
		cerr << endl; 
		exit (1);
	}

	// Comprobaciones y acciones previas
	
	if (!ExisteFichero(argv[1])) {
		cerr << endl; 		
		cerr << "Error: No existe o no puede abrirse " << argv[1] << endl;
		cerr << endl; 
		exit (2);
	}
	
	int umbral = atoi (argv[2]);
	
	if (umbral < 0 || umbral > 255) {
		cerr << endl;
		cerr << "Error: El valor umbral debe ser un número entero entre" 
			 << "0 y 255" << endl;
		cerr << endl;
		exit (3);
	}


	// Asociación de flujos a ficheros
	
	ifstream fi (argv[1], ios::binary);
	
	if (!fi) {
		cerr << endl; 		
		cerr << "Error: No pudo crearse " << argv[1] << endl;
		cerr << endl; 
		exit (4);
	}
	
	ofstream fo (argv[3], ios::binary);

	// Procesamiento
	
	// Copiar la cabecera del fichero original en el fichero binarizado
	
	string cadena;
	string formato;
	
	getline (fi, cadena);
	formato = cadena;
	
	fo << cadena << endl;
	
	// Copiar los comentarios de la cabecera
	
	getline (fi, cadena);
	
	while (cadena[0] == '#') {
		
		fo << cadena << endl;
		
		getline (fi, cadena);
	}
	
	// Columnas y filas
	
	fo << cadena << endl;
	
	istringstream iss(cadena);
	int filas, columnas;
	
	iss >> cadena;
	
	columnas = stoi (cadena);
	
	iss >> cadena;
	
	filas = stoi (cadena);
	
	getline (fi, cadena);
	
	fo << cadena << endl;
	
	if (formato == "P5") {
		unsigned char pixel;	// unsigned para que sea [0, 255]
		
		for (int i = 0 ; i < (filas * columnas) ; i++) {
			
			// Leer un pixel
			
			fi.read (reinterpret_cast<char *>(&pixel), 1);
			
			if (pixel >= umbral)
				pixel = 255;
			else
				pixel = 0;
			
			// Escribir el pixel tras su umbralización
			
			fo.write (reinterpret_cast<const char *>(&pixel), 1);
		}
	}
	else if (formato == "P2") {
		int pixel;
		
		for (int i = 0 ; i < (filas * columnas) ; i++) {
			
			// Leer un pixel
			
			fi >> pixel;
			
			if (pixel >= umbral)
				pixel = 255;
			else
				pixel = 0;
			
			// Escribir el pixel tras su umbralización
			
			fo << setw(3) << pixel << " ";
			
			if (i % 20 == 0)
				fo << endl;
		}
	}
	

	// Cierre de flujos
	
	fi.close();
	fo.close();

	cout << "Binarización realizada con éxito." << endl;

	return 0;
}


